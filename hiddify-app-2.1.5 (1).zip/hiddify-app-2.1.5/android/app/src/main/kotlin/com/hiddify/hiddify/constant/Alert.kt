package com.hiddify.hiddify.constant

enum class Alert {
    RequestVPNPermission,
    RequestNotificationPermission,
    EmptyConfiguration,
    StartCommandServer,
    CreateService,
    StartService
}