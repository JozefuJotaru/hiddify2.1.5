package com.hiddify.hiddify.constant

object PerAppProxyMode {
    const val OFF = "off"
    const val INCLUDE = "include"
    const val EXCLUDE = "exclude"
}